const API_URL = 'http://localhost:3000';

// --- UTILITÁRIOS ---
function getHeaders() {
    const token = localStorage.getItem('token');
    return { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };
}

function verificarAutenticacao() {
    const token = localStorage.getItem('token');
    if (!token && !window.location.pathname.includes('login.html')) {
        window.location.href = 'login.html';
    }
}

function carregarUsuarioSidebar() {
    const u = JSON.parse(localStorage.getItem('usuario'));
    if (u) {
        const nomeEl = document.querySelector('.user-details h3');
        const avtEl = document.querySelector('.avatar-circle');
        if (nomeEl) nomeEl.textContent = u.nome;
        if (avtEl) avtEl.textContent = u.nome.substring(0, 2).toUpperCase();
    }
}

// --- LOGIN ---
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('emailInput').value;
        const senha = document.getElementById('senhaInput').value;
        try {
            const res = await fetch(`${API_URL}/auth/login`, {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ email, senha })
            });
            const data = await res.json();
            if (res.ok) {
                localStorage.setItem('token', data.token);
                localStorage.setItem('usuario', JSON.stringify(data.usuario));
                window.location.href = 'consulta.html';
            } else alert(data.erro);
        } catch (e) { alert('Erro de conexão'); }
    });
}

// --- CONSULTA ---
const listaDocumentos = document.getElementById('listaDocumentos');
if (listaDocumentos) {
    async function carregarDocs() {
        try {
            const resDocs = await fetch(`${API_URL}/api/documentos`, { headers: getHeaders() });
            const docs = await resDocs.json();
            const resSetores = await fetch(`${API_URL}/api/setores`, { headers: getHeaders() });
            const setores = await resSetores.json();
            
            const getSetor = (id) => { const s = setores.find(x => x.id == id); return s ? s.nome : id; };

            listaDocumentos.innerHTML = '';
            docs.forEach(doc => {
                listaDocumentos.innerHTML += `
                <div class="dark-card">
                    <div class="card-header">
                        <strong>DOC-${doc.id}</strong>
                        <span class="tag tag-yellow">${doc.statusAtual}</span>
                    </div>
                    <div class="card-body">
                        <p>De: ${getSetor(doc.setorOrigemID)} <br> Para: ${getSetor(doc.setorDestinoID)}</p>
                        <small>${doc.tipoDocumento} - ${doc.prioridade}</small>
                    </div>
                </div>`;
            });
        } catch (e) { listaDocumentos.innerHTML = '<p>Erro ao carregar</p>'; }
    }
    carregarDocs();
}

// --- NOVO ENVIO ---
const formNovoEnvio = document.getElementById('formNovoEnvio');
if (formNovoEnvio) {
    fetch(`${API_URL}/api/setores`, { headers: getHeaders() })
        .then(r => r.json())
        .then(setores => {
            const sel = document.getElementById('setorDestinoDoc');
            setores.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id; opt.text = s.nome; sel.appendChild(opt);
            });
        });

    formNovoEnvio.addEventListener('submit', async (e) => {
        e.preventDefault();
        const user = JSON.parse(localStorage.getItem('usuario'));
        const body = {
            tipoDocumento: document.getElementById('tipoDoc').value,
            prioridade: document.getElementById('prioridadeDoc').value,
            setorDestinoID: parseInt(document.getElementById('setorDestinoDoc').value),
            descricao: document.getElementById('obsDoc').value,
            setorOrigemID: user.setorID, remetenteID: user.id
        };
        const res = await fetch(`${API_URL}/api/documentos`, {
            method: 'POST', headers: getHeaders(), body: JSON.stringify(body)
        });
        if(res.ok) window.location.href = 'consulta.html';
        else alert('Erro ao enviar');
    });
}

// --- SETORES (NOVO) ---
const listaSetores = document.getElementById('listaSetores');
if (listaSetores) {
    async function loadSetores() {
        const res = await fetch(`${API_URL}/api/setores`, { headers: getHeaders() });
        const setores = await res.json();
        listaSetores.innerHTML = '';
        setores.forEach(s => {
            listaSetores.innerHTML += `
            <div class="dark-card">
                <h3>${s.nome}</h3>
                <p>Responsável: ${s.responsavel || 'N/A'}</p>
            </div>`;
        });
    }
    loadSetores();
}

// --- USUÁRIOS (NOVO) ---
const listaUsuarios = document.getElementById('listaUsuarios');
if (listaUsuarios) {
    async function loadUsers() {
        const res = await fetch(`${API_URL}/api/colaboradores`, { headers: getHeaders() });
        const users = await res.json();
        listaUsuarios.innerHTML = '';
        users.forEach(u => {
            listaUsuarios.innerHTML += `
            <div class="dark-card" style="display:flex; justify-content:space-between;">
                <div><strong>${u.nome}</strong><br><small>${u.email}</small></div>
                <span class="tag tag-blue">${u.tipo}</span>
            </div>`;
        });
    }
    loadUsers();
}

// --- LÓGICA: NOVO SETOR (novo_setor.html) ---
const formNovoSetor = document.getElementById('formNovoSetor');
if (formNovoSetor) {
    formNovoSetor.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            nome: document.getElementById('nomeSetor').value,
            sigla: document.getElementById('siglaSetor').value,
            responsavel: document.getElementById('respSetor').value
        };

        try {
            const res = await fetch(`${API_URL}/api/setores`, {
                method: 'POST', headers: getHeaders(), body: JSON.stringify(payload)
            });
            if (res.ok) {
                alert('Setor criado com sucesso!');
                window.location.href = 'setores.html';
            } else {
                alert('Erro ao criar setor');
            }
        } catch (err) { alert('Erro na requisição'); }
    });
}

// --- LÓGICA: NOVO USUÁRIO (novo_usuario.html) ---
const formNovoUsuario = document.getElementById('formNovoUsuario');
if (formNovoUsuario) {
    // 1. Carrega setores no Select
    fetch(`${API_URL}/api/setores`, { headers: getHeaders() })
        .then(r => r.json())
        .then(setores => {
            const sel = document.getElementById('setorUser');
            sel.innerHTML = '<option value="">Selecione...</option>';
            setores.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id; opt.text = s.nome; sel.appendChild(opt);
            });
        });

    // 2. Envia o cadastro
    formNovoUsuario.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            nome: document.getElementById('nomeUser').value,
            email: document.getElementById('emailUser').value,
            senha: document.getElementById('senhaUser').value,
            tipo: document.getElementById('tipoUser').value,
            setorID: parseInt(document.getElementById('setorUser').value)
        };

        if (!payload.setorID) { alert('Selecione um setor!'); return; }

        try {
            const res = await fetch(`${API_URL}/api/colaboradores`, {
                method: 'POST', headers: getHeaders(), body: JSON.stringify(payload)
            });
            const data = await res.json();
            
            if (res.ok) {
                alert('Usuário criado com sucesso!');
                window.location.href = 'usuarios.html';
            } else {
                alert('Erro: ' + (data.erro || 'Falha ao criar'));
            }
        } catch (err) { alert('Erro na requisição'); }
    });
}

// Global
document.addEventListener('DOMContentLoaded', () => {
    verificarAutenticacao();
    carregarUsuarioSidebar();
    const btn = document.querySelector('.btn-logout');
    if(btn) btn.onclick = (e) => { e.preventDefault(); localStorage.clear(); window.location.href='login.html'; }
});