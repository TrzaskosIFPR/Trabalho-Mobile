const express = require('express');
const cors = require('cors'); // Para permitir que seu HTML acesse a API
const app = express();
const port = 3000;

// Middlewares
app.use(cors()); // Libera acesso de qualquer origem (útil para desenvolvimento)
app.use(express.json()); // Permite ler JSON no body das requisições

// Importação das Rotas
const authRoutes = require('./routes/AuthRoutes');
const colaboradorRoutes = require('./routes/ColaboradorRoutes');
const documentoRoutes = require('./routes/DocumentoRoute'); // Confirme se o nome do arquivo é Route ou Routes
const setorRoutes = require('./routes/SetorRoutes');
const movimentacaoRoutes = require('./routes/MovimentacaoRoutes');

// Definição das Rotas
app.use('/auth', authRoutes);
app.use('/api/colaboradores', colaboradorRoutes);
app.use('/api/documentos', documentoRoutes);
app.use('/api/setores', setorRoutes);
app.use('/api/movimentacoes', movimentacaoRoutes);

// Rota de teste
app.get('/', (req, res) => {
    res.send('API DocRastreio rodando com sucesso!');
});

// Iniciar Servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
}); 