const express = require('express');
const router = express.Router();
const MovimentacaoController = require('../controllers/MovimentacaoController');


router.post('/', MovimentacaoController.registrarTransito);

module.exports = router;