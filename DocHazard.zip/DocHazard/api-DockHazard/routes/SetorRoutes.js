const express = require('express');
const router = express.Router();
const SetorController = require('../controllers/SetorController');

router.get('/', SetorController.listar);
router.post('/', SetorController.criar);

module.exports = router;