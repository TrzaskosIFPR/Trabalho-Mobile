const express = require('express');
const router = express.Router();
const ColaboradorController = require('../controllers/ColaboradorController');

router.get('/', ColaboradorController.listar);
router.post('/', ColaboradorController.criar);

module.exports = router;