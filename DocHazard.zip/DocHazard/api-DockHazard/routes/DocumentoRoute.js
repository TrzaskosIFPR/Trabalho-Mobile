const express = require('express');
const router = express.Router();
const DocumentoController = require('../controllers/DocumentoController');

router.get('/', DocumentoController.listar);
router.post('/', DocumentoController.criar); // <--- Essa linha é essencial

module.exports = router;