const DataStore = require('../models/DataStore'); // Importação Correta

class ColaboradorService {
    listar() {
        return DataStore.colaboradores; // Acesso direto
    }

    criar(nome, email, senha, setorID, tipo) {
        if (!nome || !email || !setorID) throw new Error("Dados incompletos.");

        const setorExiste = DataStore.setores.find(s => s.id === parseInt(setorID));
        if (!setorExiste) throw new Error("Setor não existe.");

        const emailExiste = DataStore.colaboradores.find(c => c.email === email);
        if (emailExiste) throw new Error("E-mail já cadastrado.");

        const novoColab = {
            id: DataStore.proxId(DataStore.colaboradores), // Usa a função nova
            nome, email,
            senha: senha || "123456",
            setorID: parseInt(setorID),
            tipo: tipo || "Colaborador"
        };

        DataStore.colaboradores.push(novoColab);
        return novoColab;
    }
}
module.exports = new ColaboradorService();