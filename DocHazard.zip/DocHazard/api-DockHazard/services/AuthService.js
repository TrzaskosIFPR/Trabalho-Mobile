const DataStore = require('../models/DataStore'); // Certifique-se que o caminho está certo
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'liedson'; // Em produção, isso iria em variáveis de ambiente

class AuthService {
    
    login(email, senha) {
        const usuario = DataStore.colaboradores.find(c => c.email === email);
        if (!usuario || usuario.senha !== senha) { // Comparação direta
        throw new Error("Credenciais inválidas");
}

        // 3. Gerar o Token (O "Crachá" que vale por 1 hora)
        // Guardamos no token o ID e o TIPO do usuário para usar nas permissões depois
        const token = jwt.sign(
            { id: usuario.id, tipo: usuario.tipo, setorID: usuario.setorID }, 
            SECRET_KEY, 
            { expiresIn: '1h' }
        );

        // 4. Preparar dados para retornar (sem mandar a senha de volta!)
        const usuarioSemSenha = { 
            id: usuario.id, 
            nome: usuario.nome, 
            email: usuario.email, 
            tipo: usuario.tipo,
            setorID: usuario.setorID
        };

        return { token, usuario: usuarioSemSenha };
    }
}
// Exemplo trecho do AuthService.js


module.exports = new AuthService();