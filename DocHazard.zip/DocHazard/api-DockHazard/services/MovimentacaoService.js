const DataStore = require('../models/DataStore');

class MovimentacaoService {
    registrarTransito(documentoID, portadorID) {
        const indexDoc = DataStore.documentos.findIndex(d => d.id === documentoID);
        if (indexDoc === -1) throw new Error("Documento não encontrado.");
        
        const doc = DataStore.documentos[indexDoc];
        if (doc.statusAtual === "Entregue") throw new Error("Documento já entregue.");

        const portador = DataStore.colaboradores.find(c => c.id === portadorID);
        if (!portador || portador.tipo !== 'Portador') {
            throw new Error("Apenas Portadores podem mover documentos.");
        }

        DataStore.documentos[indexDoc].statusAtual = "Transitando";

        const mov = {
            id: DataStore.proxId(DataStore.movimentacoes),
            documentoID, portadorID,
            setorOrigemID: doc.setorAtualID,
            dataHora: new Date().toISOString(),
            status: "Em Trânsito"
        };
        DataStore.movimentacoes.push(mov);
        return mov;
    }

    buscarHistorico(documentoID) {
        return DataStore.movimentacoes.filter(m => m.documentoID === documentoID);
    }
}
module.exports = new MovimentacaoService();