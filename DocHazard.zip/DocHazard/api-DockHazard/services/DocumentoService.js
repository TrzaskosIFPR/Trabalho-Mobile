const DataStore = require('../models/DataStore');

class DocumentoService {
    listar() {
        return DataStore.documentos;
    }

    criar(dadosDoc) {
        const { tipoDocumento, prioridade, setorOrigemID, setorDestinoID, remetenteID, descricao } = dadosDoc;

        if (!tipoDocumento || !setorDestinoID) {
            throw new Error("Dados obrigatórios faltando.");
        }

        const novoDoc = {
            id: DataStore.proxId(DataStore.documentos),
            tipoDocumento, prioridade, descricao,
            statusAtual: "Pendente",
            setorOrigemID, setorAtualID: setorOrigemID, setorDestinoID, remetenteID,
            dataEnvio: new Date().toISOString()
        };

        DataStore.documentos.push(novoDoc);
        return novoDoc;
    }
}
module.exports = new DocumentoService();