const DataStore = require('../models/DataStore');

class SetorService {
    listar() { return DataStore.setores; }

    criar(nome, sigla, responsavel) {
        if (!nome) throw new Error("Nome do setor é obrigatório.");
        
        const novoSetor = {
            id: DataStore.proxId(DataStore.setores),
            nome,
            sigla: sigla || nome.substring(0,3).toUpperCase(),
            responsavel: responsavel || "N/A",
            qtdPessoas: 0
        };
        DataStore.setores.push(novoSetor);
        return novoSetor;
    }
}
module.exports = new SetorService();