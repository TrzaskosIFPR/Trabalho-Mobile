class DataStore {
    constructor() {
        // 1. Tabela de Setores
        this.setores = [
            { id: 1, nome: "Recursos Humanos (RH)",
              sigla: "RH",
              responsavel: "Ana Maria",
              qtdPessoas: 5 },
            { id: 2, nome: "Tecnologia (TI)",
              sigla: "TI",
              responsavel: "Carlos Dev",
              qtdPessoas: 10 },
            { id: 3, nome: "Financeiro",
              sigla: "FIN",
              responsavel: "Roberto Grana",
              qtdPessoas: 8 },
            { id: 4, nome: "Logística / Entregas",
              sigla: "LOG",
              responsavel: "Amanda Entregas",
              qtdPessoas: 12 }
        ];

        // 2. Colaboradores
        this.colaboradores = [
            { id: 1, nome: "Lauro Birinto",
              email: "Labirinto@empresa.com",
              senha: "123",
              tipo: "Comum",
              setorID: 1 },
            { id: 2,
              nome: "Maria Souza",
              email: "maria@empresa.com",
              senha: "123", tipo: "Admin",
              setorID: 2 },
            { id: 3,
              nome: "Carlos Entregador",
              email: "carlos@empresa.com",
              senha: "123",
              tipo: "Portador",
              setorID: 4 }
        ];

        // 3. Documentos
        this.documentos = [
            {
                id: 1, tipoDocumento: "Contrato",
                prioridade: "Alta",
                descricao: "Contrato Inicial",
                dataEnvio: new Date().toISOString(), statusAtual: "Pendente",
                setorOrigemID: 1, setorAtualID: 1, setorDestinoID: 2, remetenteID: 1
            }
        ];

        // 4. Movimentações
        this.movimentacoes = [];
        this.recebimentos = [];
    }

    // Função utilitária para gerar o próximo ID
    proxId(lista) {
        if (lista.length === 0) return 1;
        return Math.max(...lista.map(item => item.id)) + 1;
    }
}

module.exports = new DataStore();