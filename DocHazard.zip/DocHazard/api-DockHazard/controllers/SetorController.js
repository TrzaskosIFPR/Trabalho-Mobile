const SetorService = require('../services/SetorService');

class SetorController {
    listar(req, res) {
        return res.json(SetorService.listar());
    }

    criar(req, res) {
        try {
            const { nome, sigla, responsavel } = req.body;
            const setor = SetorService.criar(nome, sigla, responsavel);
            return res.status(201).json(setor);
        } catch (erro) {
            return res.status(400).json({ erro: erro.message });
        }
    }
}
module.exports = new SetorController();