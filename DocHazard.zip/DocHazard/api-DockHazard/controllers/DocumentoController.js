const DocumentoService = require('../services/DocumentoService');

class DocumentoController {

    // Método para LISTAR (GET)
    listar(req, res) {
        try {
            const documentos = DocumentoService.listar();
            return res.json(documentos);
        } catch (error) {
            return res.status(500).json({ erro: error.message });
        }
    }

    // Método para CRIAR (POST) -> É este que o formulário usa!
    criar(req, res) {
        try {
            // Pega os dados que vieram do formulário
            const { tipoDocumento, prioridade, setorDestinoID, setorOrigemID, remetenteID, descricao } = req.body;

            // Validação básica
            if (!setorDestinoID || !tipoDocumento) {
                return res.status(400).json({ erro: "Campos obrigatórios faltando." });
            }

            // Chama o serviço para salvar
            const novoDoc = DocumentoService.criar({
                tipoDocumento,
                prioridade,
                setorDestinoID,
                setorOrigemID,
                remetenteID,
                descricao
            });

            return res.status(201).json(novoDoc);

        } catch (error) {
            return res.status(400).json({ erro: error.message });
        }
    }
}

module.exports = new DocumentoController();