const MovimentacaoService = require('../services/MovimentacaoService');

class MovimentacaoController {

    registrarTransito(req, res) {
        try {
            const { documentoID, portadorID } = req.body;
            
            // Chama o serviço que contém as regras de negócio
            const movimentacao = MovimentacaoService.registrarTransito(documentoID, portadorID);
            
            return res.status(201).json(movimentacao);
        } catch (erro) {
            // Retorna o erro vindo do Service (ex: "Documento já entregue")
            return res.status(400).json({ erro: erro.message });
        }
    }

    listarHistorico(req, res) {
        const docId = parseInt(req.params.id);
        const historico = MovimentacaoService.buscarHistorico(docId);
        return res.json(historico);
    }
}

module.exports = new MovimentacaoController();