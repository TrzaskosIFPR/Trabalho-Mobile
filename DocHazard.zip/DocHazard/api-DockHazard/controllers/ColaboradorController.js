const ColaboradorService = require('../services/ColaboradorService');

class ColaboradorController {
    listar(req, res) {
        return res.json(ColaboradorService.listar());
    }

    criar(req, res) {
        try {
            const { nome, email, senha, setorID, tipo } = req.body;
            const novoColab = ColaboradorService.criar(nome, email, senha, setorID, tipo);
            return res.status(201).json(novoColab);
        } catch (erro) {
            return res.status(400).json({ erro: erro.message });
        }
    }
}
module.exports = new ColaboradorController();