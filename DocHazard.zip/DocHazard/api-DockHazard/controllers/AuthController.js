const AuthService = require('../services/AuthService');

class AuthController {
    
    async login(req, res) {
        try {
            const { email, senha } = req.body;

            // Chama o serviço
            const resultado = AuthService.login(email, senha);

            // Retorna sucesso (200) com o token e dados do usuário
            return res.status(200).json({
                msg: 'Autenticação realizada com sucesso',
                token: resultado.token,
                usuario: resultado.usuario
            });

        } catch (error) {
            // Se der erro (senha errada ou usuário não existe)
            return res.status(401).json({ erro: error.message });
        }
    }
}

module.exports = new AuthController();